<?php
	class manage_meter{
		public function __construct(){}

		public function getBillingList(){
			return 'billings';
		}
		public function getAddUserView(){
			return 'billings';
		}
		public function getAddMeterView(){
			return 'billings_add';
		}
		public function getMeterView(){
			return 'billings_view';
		}
		public function getBillView(){
			return 'bill';
		}
		public function getLoginRecords(){
			return 'admin_login_records_view';
		}
		public function getUpdateUserView(){
			return 'client_edit';
		}

		public function getMeterData($data, $meternum){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/meter_model.php';
			$obj=new meter_model();
			$obj->meter_number=$meternum;
			$obj->reading=$data['reading'];
			$obj->reading_date=$data['reading_date'];
			$obj->billing_month=$data['billing_month'];
			$obj->price=$data['price'];
			return $obj;
		}

		public function getClientEditData($data, $id){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/client_model.php';
			$obj=new client_model();
			$obj->ownerId=$id;
			$obj->fname=$data['fname'];
			$obj->lname=$data['lname'];
			$obj->mi=$data['mi'];
			$obj->address=$data['address'];
			$obj->contact=$data['contact'];
			$obj->meter_number=$data['meter_number'];
			return $obj;
		}

		public function getBillData($meterid,$id,$previd){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/bill_model.php';
			$bill=new bill_model();
			$owner_sql=$bill->getOwnerDetails($id);
			$owner_data=mysqli_fetch_array($owner_sql);
			$meter_sql=$bill->getMeterDetails($meterid);
			$meter_data=mysqli_fetch_array($meter_sql);
			$bill->owners_id=$id;
		 	$bill->price=$meter_data['price'];
		 	$bill->billing_date=$meter_data['reading_date'];
		 	$bill->meter_id=$meterid;
		 	$prev_reading=$bill->GetPreviousReading($previd, $meter_data['meter_number']);
		 	if($prev_reading['reading']==""){
		 		$prev_reading['reading']=0;
		 		$bill->previous=$prev_reading['reading'];
		 	}else{
		 		$bill->previous=$prev_reading['reading'];
		 	}
		 	$consumption=$bill->ComputeConsumption($prev_reading['reading'],$meter_data['reading']);
		 	$bill->consumption=$consumption;
		 	$bill->totalbill=$bill->ComputeBill($consumption,$meter_data['price']);
		 	$add_billdata=$bill->AddBill();
		 	$bill->updateIsComputedStatus($meterid);
		}

		public function getLoginData($data){
			include $_SERVER['DOCUMENT_ROOT'].'/hanna/food_genie/applications/models/login_model.php';
			$obj=new login_model();
			$obj->username=$data['username'];
			$obj->date=$data['date'];
			return $obj;
		}

		public function addMeter($data, $meternum){
			$obj=$this->getMeterData($data, $meternum);
			return $obj->AddMeter();	
		}

		public function addBill($data){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/bill_model.php';
			$obj=new bill_model();
			$result=$obj->AddBill($data);
			return $result;
		}

		public function getMeterReading($meterid){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/meter_model.php';
			$meter=new meter_model();
			$sql=$meter->GetMeterData($meterid);
			$meter_data=mysqli_fetch_array($sql);
			return $meter_data;
		}

		public function getPreviousReading($curr_date){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/meter_model.php';
			$m_data=new meter_model();
			$sql=$m_data->GetPreviousReading($curr_date);
			$result=mysqli_fetch_array($sql);
			echo $result;
			return $result;
		}

		public function getConsumption($meter_data,$previous){
			$current=$meter_data['reading'];
			//$previous=$bill['previous'];
			$consumption=$current-$previous;
			return $consumption;
		}

		public function calculateBill($consumption, $price){
			$totalbill=$consumption*$price;
			return $totalbill;
		}

		public function deleteUser($id){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/client_model.php';
			$obj=new client_model();
			return $obj->deleteClient($id);	
		}

		public function updateUser($data, $id){
			$obj=$this->getClientEditData($data, $id);
			return $obj->updateClient();
		}
	}

	$obj=new manage_meter();
	$page='';

	if(isset($_GET['view'])){
		$view=$_GET['view'];
		if($view=='billing_list'){
			$page=$obj->getBillingList();
		}
		else if($view=='add_user_view'){
			$page=$obj->getAddUserView();
		}
		else if ($view=='add_meter') {
			$page=$obj->getAddMeterView();
		}
		else if ($view=='view_meter') {
			$page=$obj->getMeterView();
		}
		else if ($view=='view_bill') {
			$page=$obj->getBillView();
		}
		else if($view=='login_records'){
			$page=$obj->getLoginRecords();
		}
		else if($view=='edit_user'){
			$page=$obj->getUpdateUserView();
		}
		else{
			$page=$obj->getUsersList();
		}

		include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/view/'.$page.'.php';
	}

	if(isset($_GET['action'])){
		$action=$_GET['action'];
		if($action=='add_meter'){
			$meternum=$_GET['meternum'];
			$owner=$_GET['owner'];
			$addmeter=$obj->addMeter($_POST, $meternum);
			//$addbbill=$obj->addBill($_POST, $owner, $meternum);
			if($addmeter==true)
				$msg="Successfully Saved";
			else
				$msg="Oops! Something went wrong. Please try again.";
			header("Location:manage_meter.php?view=billing_list");
		}
		else if($action=='add_reading_view'){
			$meternum=$_GET['meternum'];
			$owner=$_GET['owner'];
			header("Location:manage_meter.php?view=add_meter&meternum=$meternum&owner=$owner");
		}
		else if($action=='view_meters'){
			$meternum=$_GET['meternum'];
			$id = $_GET['id'];
			header("Location:manage_meter.php?view=view_meter&meternum=$meternum&id=$id");
		}
		else if($action=='compute_bill'){
			$meterid=$_GET['meterid'];
			$id = $_GET['id'];
			$previd = $_GET['previd'];
			$bill_data=$obj->getBillData($meterid,$id,$previd);
			header("Location:manage_meter.php?view=view_bill&meterid=$meterid&id=$id");
		}else if($action=='view_bill'){
			$meterid=$_GET['meterid'];
			$id = $_GET['id'];
			$previd = $_GET['previd'];
			header("Location:manage_meter.php?view=view_bill&meterid=$meterid&id=$id");
		}
		else if($action=='delete'){
			$id=$_GET['id'];
			$obj->deleteUser($id);
			header("Location:manage_clients.php?view=users_list");
		}
		else if($action=='edit_view'){
			$id=$_GET['id'];
			header("Location:manage_clients.php?view=edit_user&id=$id");
		}
		else if($action=='edit_client'){
			$id=$_GET['id'];
			$result=$obj->updateUser($_POST, $id);
			if($result==true)
				echo $msg="Successfully Saved";
			else
				echo $msg="Oops! Something went wrong. Please try again.";
			header("Location:manage_clients.php?view=users_list");
		}
	}
?>