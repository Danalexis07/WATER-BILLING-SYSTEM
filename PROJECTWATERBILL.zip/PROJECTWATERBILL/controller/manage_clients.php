<?php
	class manage_clients{
		public function __construct(){}

		public function getUsersList(){
			return 'clients';
		}
		public function getAddUserView(){
			return 'clients';
		}
		public function getLoginRecords(){
			return 'admin_login_records_view';
		}
		public function getUpdateUserView(){
			return 'client_edit';
		}

		public function getUserData($data){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/client_model.php';
			$obj=new client_model();
			$obj->lname=$data['lname'];
			$obj->fname=$data['fname'];
			$obj->mi=$data['mi'];
			$obj->address=$data['address'];
			$obj->contact=$data['contact'];
			$obj->meter_number=$data['meter_number'];
			return $obj;
		}

		public function getClientEditData($data, $id){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/client_model.php';
			$obj=new client_model();
			$obj->ownerId=$id;
			$obj->fname=$data['fname'];
			$obj->lname=$data['lname'];
			$obj->mi=$data['mi'];
			$obj->address=$data['address'];
			$obj->contact=$data['contact'];
			$obj->meter_number=$data['meter_number'];
			return $obj;
		}

		public function getLoginData($data){
			include $_SERVER['DOCUMENT_ROOT'].'/hanna/food_genie/applications/models/login_model.php';
			$obj=new login_model();
			$obj->username=$data['username'];
			$obj->date=$data['date'];
			return $obj;
		}

		public function addUser($data){
			$obj=$this->getUserData($data);
			return $obj->addClient();	
		}

		public function deleteUser($id){
			include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/client_model.php';
			$obj=new client_model();
			return $obj->deleteClient($id);	
		}

		public function updateUser($data, $id){
			$obj=$this->getClientEditData($data, $id);
			return $obj->updateClient();
		}
	}

	$obj=new manage_clients();
	$page='';

	if(isset($_GET['view'])){
		$view=$_GET['view'];
		if($view=='users_list'){
			$page=$obj->getUsersList();
		}
		else if($view=='add_user_view'){
			$page=$obj->getAddUserView();
		}
		else if($view=='login_records'){
			$page=$obj->getLoginRecords();
		}
		else if($view=='edit_user'){
			$page=$obj->getUpdateUserView();
		}
		else{
			$page=$obj->getUsersList();
		}

		include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/view/'.$page.'.php';
	}

	if(isset($_GET['action'])){
		$action=$_GET['action'];
		if($action=='add_client'){
			$result=$obj->addUser($_POST);
			if($result==true)
				$msg="Successfully Saved";
			else
				$msg="Oops! Something went wrong. Please try again.";
			header("Location:manage_clients.php?view=add_user_view");
		}
		else if($action=='delete'){
			$id=$_GET['id'];
			$obj->deleteUser($id);
			header("Location:manage_clients.php?view=users_list");
		}
		else if($action=='edit_view'){
			$id=$_GET['id'];
			header("Location:manage_clients.php?view=edit_user&id=$id");
		}
		else if($action=='edit_client'){
			$id=$_GET['id'];
			$result=$obj->updateUser($_POST, $id);
			if($result==true)
				echo $msg="Successfully Saved";
			else
				echo $msg="Oops! Something went wrong. Please try again.";
			header("Location:manage_clients.php?view=users_list");
		}
	}
?>