-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2019 at 10:55 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `waterbilling`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `bill_id` int(10) NOT NULL,
  `owners_id` int(10) NOT NULL,
  `price` varchar(20) NOT NULL,
  `billing_date` varchar(20) NOT NULL,
  `totalbill` double NOT NULL,
  `meter_id` int(11) NOT NULL,
  `previous` double NOT NULL,
  `consumption` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`bill_id`, `owners_id`, `price`, `billing_date`, `totalbill`, `meter_id`, `previous`, `consumption`) VALUES
(22, 10023, '1', '2019-01-02', 120, 14, 0, 120),
(21, 10003, '0.2', '2019-12-09', 20.4, 10, 0, 102),
(23, 9999, '1', '2019-01-30', -3672, 9, 3795, -3672),
(24, 10025, '10', '2019-12-20', 1000, 15, 0, 100),
(25, 10025, '10', '2019-12-21', 1000, 16, 100, 100),
(26, 9999, '0.5', '0000-00-00', 2581.5, 5, 0, 5163),
(27, 9999, '0.5', '0000-00-00', -684, 6, 5163, -1368),
(28, 10026, '10', '2019-12-12', 1000, 17, 0, 100),
(29, 1, '10', '2019-12-21', 3500, 18, 0, 350),
(30, 1, '10', '2019-12-22', 500, 19, 350, 50),
(31, 10029, '10', '2019-12-01', 1000, 20, 0, 100),
(32, 10029, '10', '2019-12-07', 50, 21, 100, 5),
(33, 10030, '10', '2019-12-13', 1000, 22, 0, 100),
(34, 10030, '10', '2019-12-14', 2500, 23, 100, 250),
(35, 10030, '10', '2019-12-14', 2500, 23, 100, 250),
(36, 10030, '10', '2019-12-18', 6000, 27, 0, 600),
(37, 10029, '10', '2019-12-17', 3500, 28, 0, 350),
(38, 10029, '10', '2019-12-20', 500, 29, 350, 50),
(39, 10029, '55', '2019-12-16', 5500, 24, 0, 100),
(40, 10029, '55', '2019-12-16', 5500, 24, 0, 100),
(41, 10029, '10', '2019-12-16', 3000, 25, 100, 300),
(42, 10029, '10', '2019-12-17', 1000, 26, 400, 100);

-- --------------------------------------------------------

--
-- Table structure for table `meter`
--

CREATE TABLE `meter` (
  `meter_id` int(11) NOT NULL,
  `meter_number` varchar(15) NOT NULL,
  `reading` double NOT NULL,
  `reading_date` date NOT NULL,
  `billing_month` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `isComputed` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meter`
--

INSERT INTO `meter` (`meter_id`, `meter_number`, `reading`, `reading_date`, `billing_month`, `price`, `isComputed`) VALUES
(20, '1', 100, '2019-12-01', 'NOVEMBER', 10, 1),
(21, '1', 105, '2019-12-07', 'NOVEMBER', 10, 1),
(22, '5', 100, '2019-12-13', 'NOVEMBER', 10, 1),
(23, '5', 350, '2019-12-14', 'dec', 10, 1),
(24, '1', 100, '2019-12-16', 'NOVEMBER', 55, 1),
(25, '1', 400, '2019-12-16', '', 10, 1),
(26, '1', 500, '2019-12-17', '', 10, 1),
(27, '5', 600, '2019-12-18', 'AGAY AY', 10, 1),
(28, '1', 350, '2019-12-17', 'DECEMBER', 10, 1),
(29, '1', 400, '2019-12-20', 'DECEMBER', 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `owners`
--

CREATE TABLE `owners` (
  `owners_id` int(10) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `fname` varchar(60) NOT NULL,
  `mi` varchar(2) NOT NULL,
  `address` varchar(60) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `meter_number` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `owners`
--

INSERT INTO `owners` (`owners_id`, `lname`, `fname`, `mi`, `address`, `contact`, `meter_number`) VALUES
(10029, 'FRANCIA', 'DAN ALEXIS', 'BA', 'SOMOJE SAN JUAN ', '06895690457', '1'),
(10030, 'TAER', 'ROGELIO', 'AM', 'PANIAN SAINT BERNARD', '09876543456', '5');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `trn_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `trn_date`) VALUES
(1, 'asd', '60d31eb37595dd44584be5ef363283e3', '2019-12-12 07:43:16'),
(2, 'asd', '60d31eb37595dd44584be5ef363283e3', '2019-12-12 07:44:21'),
(3, 'asd', '60d31eb37595dd44584be5ef363283e3', '2019-12-12 07:44:43'),
(4, 'dante', '81dc9bdb52d04dc20036dbd8313ed055', '2019-12-12 07:45:05'),
(5, 'jr', '81dc9bdb52d04dc20036dbd8313ed055', '2019-12-12 07:54:02'),
(6, 'dandan', '81dc9bdb52d04dc20036dbd8313ed055', '2019-12-12 14:59:30'),
(7, 'dandan', '81dc9bdb52d04dc20036dbd8313ed055', '2019-12-12 15:00:52'),
(8, 'hanna', '81dc9bdb52d04dc20036dbd8313ed055', '2019-12-12 15:02:01'),
(9, 'dan', '81dc9bdb52d04dc20036dbd8313ed055', '2019-12-12 15:08:03'),
(10, 'dante', '81dc9bdb52d04dc20036dbd8313ed055', '2019-12-12 15:52:13'),
(11, 'hanna', '827ccb0eea8a706c4c34a16891f84e7b', '2019-12-12 15:52:41'),
(12, 'ehed', '81dc9bdb52d04dc20036dbd8313ed055', '2019-12-12 16:19:25'),
(13, 'makoy', '8ea94afd15359d2247a34e9a2a3d5b42', '2019-12-13 03:45:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`bill_id`);

--
-- Indexes for table `meter`
--
ALTER TABLE `meter`
  ADD PRIMARY KEY (`meter_id`);

--
-- Indexes for table `owners`
--
ALTER TABLE `owners`
  ADD PRIMARY KEY (`owners_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bill`
--
ALTER TABLE `bill`
  MODIFY `bill_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `meter`
--
ALTER TABLE `meter`
  MODIFY `meter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `owners`
--
ALTER TABLE `owners`
  MODIFY `owners_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10031;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
