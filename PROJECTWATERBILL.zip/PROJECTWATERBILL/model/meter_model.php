<?php include 'connect.php';
	// class user_model{
	class meter_model{	
		public $db;
		public $meter_id; 				//entry id
		public $meter_number;   				//id number of the meter device
		public $reading;					//kwh
		public $reading_date;						// When the reading occurred
		public $billing_month; 				//month 
		public $price; 						//price kwh
	
		public function __construct(){
			$this->db=new dbs();
		}
		
		// ALREADY MODIFIED
		//Add a new bill
		public function AddMeter(){
			$sql="INSERT INTO meter(meter_id,meter_number,reading,reading_date,billing_month,price)
			VALUES('$this->meter_id','$this->meter_number','$this->reading','$this->reading_date','$this->billing_month','$this->price')";
			$result=$this->db->execute_query($sql);
			if($result) return true;
			return false;
		}

		// ALREADY MODIFIED
		//Update the billing details.
		public function UpdateMeter(){
			$sql="UPDATE meter SET
			meter_number='$this->meter_number',
			reading='$this->reading',
			reading_date='$this->reading_date',
			billing_month='$this->billing_month',
			price='$this->price' WHERE meter_id='$this->meter_id'";
			$result=$this->db->execute_query($sql);
			if($result) return true;
			return false;	
		}
		
		// ALREADY MODIFIED
		// Delete a specific meter record.
		public function DeleteMeter($id){
			$sql="DELETE FROM meter WHERE meter_id='$id'";
			$result=$this->db->execute_query($sql);
		}
		
		// ALREADY MODIFIED
		// Get all meter records.
		public function GetMeters(){
			$sql="SELECT * FROM meter";
			return $this->db->execute_query($sql);
		}

		// ALREADY MODIFIED
		// Get a specific meter record based on the meter_id.
		public function GetMeter($num){
			$sql="SELECT * FROM meter WHERE meter_number='$num'";
			return $this->db->execute_query($sql);
		}

		public function GetMeterData($meterid){
			$sql="SELECT * FROM meter WHERE meter_id='$meterid'";
			return $this->db->execute_query($sql);
		}

		public function CalculateBill($meternum){
			$maxval="SELECT MAX(reading) FROM meter WHERE meter_number='$meternum'";
		}

		public function checkIsComputed($meterid){
			$sql="SELECT isComputed FROM meter WHERE meter_id=$meterid";
			$result=mysqli_fetch_array($this->db->execute_query($sql));
			return $result['isComputed'];
		}

		public function getOwnerDetails($id){
			$sql="SELECT * FROM owners WHERE owners_id=".$id;
			return mysqli_fetch_array($this->db->execute_query($sql));
		}
	}
?>