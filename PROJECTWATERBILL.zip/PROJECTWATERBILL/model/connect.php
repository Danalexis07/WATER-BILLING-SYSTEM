<?php
	class dbs{
		private $db;
		public function __construct(){
			$this->db = mysqli_connect("localhost", "root","","waterbilling");
			if (!$this->db){
				die("Error: Failed to connect to database!");
			}
		}
		public function execute_query($sql){
			return mysqli_query($this->db,$sql);
		}
	}		
?>
