<?php include 'connect.php';
	// class user_model{
	class bill_model{	
		public $db;
		public $bill_id;			//$meter_id; 				
		public $owners_id;			//$meter_number;   			
		public $price;				//$reading;					
		public $billing_date;		//$reading_date;				
		public $totalbill;			//$billing_month; 			 
		public $meter_id;			//$price; 
		public $previous;
		public $consumption;
		public $name;
		public $address;
		public $contact;					
	
		public function __construct(){
			$this->db=new dbs();
		}
		
		// ALREADY MODIFIED
		//Add a new bill
		//AddMeter()
		public function AddBill(){
			$sql="INSERT INTO bill(bill_id,owners_id,price,billing_date,totalbill,meter_id,previous,consumption)
			VALUES('$this->bill_id','$this->owners_id','$this->price','$this->billing_date','$this->totalbill','$this->meter_id','$this->previous','$this->consumption')";
			$result=$this->db->execute_query($sql);
			if($result) return true;
			return false;
		}

		// ALREADY MODIFIED
		//Update the billing details.
		public function UpdateBill(){
			$sql="UPDATE bill SET
			owners_id='$this->owners_id',
			price='$this->price',
			billing_date='$this->billing_date',
			totalbill='$this->totalbill',
			meter_id='$this->meter_id' WHERE 
			bill_id='$this->bill_id'";
			$result=$this->db->execute_query($sql);
			if($result) return true;
			return false;	
		}

		public function updateIsComputedStatus($meterid){
			$sql="UPDATE meter SET isComputed=1 WHERE meter_id=$meterid";
			mysqli_fetch_array($this->db->execute_query($sql));
		}
		
		// ALREADY MODIFIED
		// Delete a specific meter record.
		public function DeleteBill($id){
			$sql="DELETE FROM bill WHERE bill_id='$id'";
			$result=$this->db->execute_query($sql);
		}
		
		// ALREADY MODIFIED
		// Get all meter records.
		public function GetBills(){
			$sql="SELECT * FROM bill";
			return $this->db->execute_query($sql);
		}

		// ALREADY MODIFIED
		// Get a specific meter record based on the meter_id.
		public function GetBill($id){
			$sql="SELECT * FROM bill WHERE meter_id='$id'";
			return $this->db->execute_query($sql);
		}

		public function getOwnerDetails($id){
			$sql="SELECT * FROM owners WHERE owners_id=".$id;
			return $this->db->execute_query($sql);
		}

		public function getMeterDetails($meterid){
			$sql="SELECT * FROM meter WHERE meter_id=".$meterid;
			return $this->db->execute_query($sql);
		}

		public function GetPreviousReading($prev_id,$meternum){
			$sql="SELECT reading FROM meter WHERE meter_id=$prev_id AND meter_number=$meternum";
			return mysqli_fetch_array($this->db->execute_query($sql));
		}

		public function ComputeConsumption($prev, $curr){
			$consumption=$curr-$prev;
			return $consumption;
		}

		public function ComputeBill($consumption, $price){
			$bill=$consumption*$price;
			return $bill;
		}

		public function GetBillId($meterid,$id){
			$sql="SELECT bill_id FROM bill WHERE meter_id=$meterid AND owners_id=$id";
			return mysqli_fetch_array($this->db->execute_query($sql));
		}

		public function GetBillData($id){
			$sql="SELECT * FROM bill WHERE bill_id='$id'";
			return $this->db->execute_query($sql);
		}
	}
?>