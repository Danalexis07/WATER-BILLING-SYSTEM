<?php include 'connect.php';
	// class user_model{
	class client_model{	
		public $db;
		public $ownerId; 				//$user_id;
		public $fname;   				//$user_name;
		public $lname;					//$user_address;
		public $mi;						//$username;
		public $address; 				//$password;
		public $contactNo; 				//$position;
		public $meterNo;				//$branch;
	
		public function __construct(){
			$this->db=new dbs();
		}
		
		// public function addUser(){
		public function addClient(){
			$sql="INSERT INTO owners(owners_id,lname,fname,mi,address,contact,meter_number)
			VALUES('$this->ownerId','$this->lname','$this->fname','$this->mi','$this->address','$this->contact','$this->meter_number')";
			$result=$this->db->execute_query($sql);
			if($result) return true;
			return false;
		}

		// ALREADY MODIFIED
		//Update the owner details.
		public function updateClient(){
			$sql="UPDATE owners SET
			lname='$this->lname',
			fname='$this->fname',
			mi='$this->mi',
			address='$this->address',
			contact='$this->contact',
			meter_number='$this->meter_number' WHERE owners_id='$this->ownerId'";
			$result=$this->db->execute_query($sql);
			if($result) return true;
			return false;	
		}
		
		// ALREADY MODIFIED
		// Idelete ang data sa specific client based sa ownerId.
		public function deleteClient($id){
			$sql="DELETE FROM owners WHERE owners_id='$id'";
			$result=$this->db->execute_query($sql);
		}
		
		// ALREADY MODIFIED
		// Kuhaon ang data sa tanan clients didto sa DB.
		public function getClients(){
			$sql="SELECT * FROM owners";
			return $this->db->execute_query($sql);
		}

		// ALREADY MODIFIED
		// Kuhaon ang data sa client didto sa DB based sa ownerId nga value.
		public function getClient($id){					
			$sql="SELECT * FROM owners WHERE owners_id=".$id;
			return $this->db->execute_query($sql);
		}
	}
?>