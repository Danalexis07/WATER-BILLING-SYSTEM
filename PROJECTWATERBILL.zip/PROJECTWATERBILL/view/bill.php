<?php 
  $meter_id=$_GET['meterid'];
  $id=$_GET['id'];
 ?>
 <!-- <?php 
  // $reading = "";
  // $reading_date = "";
  // $billing_month = "";
  // $price = "";

  // if(isset($_GET['action'])=="edit_meter"){
  //   include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/meter_model.php';
  //   $user=new meter_model();
  //   $result=$user->getMeter($meter_no);
  //   $data=mysqli_fetch_array($result);

  //   $title = "EDIT READING";
  //   $reading = $data['reading'];
  //   $reading_date = $data['reading_date'];
  //   $billing_month = $data['billing_month'];
  //   $price = $data['price'];
  // }
  // else{
  //   $title = "ADD NEW READING";    
  // }
?> -->
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>WATERBILL SYSTEM BILLINGS</title>
  <!-- JAVASCRIPT -->
  <script type="text/javascript" src="../js/table/jquery-3.3.1.js"></script>
  <script type="text/javascript" src="../js/table/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="../js/table/jquery-3.3.1.min.js"></script>
  <script type="text/javascript" src="../js/table/datatables.min.js"></script>
  <script type="text/javascript" language="javascript" class="init">
      $(document).ready(function() {
        $('#example').DataTable();
      } );
  </script>
  <!-- Bootstrap Core CSS -->
  <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">

  <!-- Fonts -->
  <link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="../css/animate.css" rel="stylesheet" />
  <!-- Squad theme CSS -->
  <link href="../css/style.css" rel="stylesheet">
  <link href="../color/default.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../css/table/jquery.dataTables.min.css"/>
  <link rel="stylesheet" type="text/css" href="../css/waterbill.css"/>
  <link rel="stylesheet" type="text/css" href="../css/style.css"/>
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
  <!-- Preloader -->
  <!-- <div id="preloader">
    <div id="load"></div>
  </div> -->

  <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
    <div class="container">
      <div class="navbar-header page-scroll">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
        <a class="navbar-brand" href="index.php">
          <h1>WATERBILL SYSTEM</h1>
        </a>
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
        <ul class="nav navbar-nav">
          <li class=""><a href="../view/home.php">Home</a></li>
          <li><a href="../view/billings.php">BILLINGS</a></li>
          <li><a href="../view/clients.php">CLIENTS</a></li>
          <li><a href="../view/logout.php">LOGOUT</a></li>
          <li class="dropdown">

        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
  </nav>

  <!-- Section: intro -->
  

  

  <!-- Section: contact -->
  <section id="contact" class="home-section text-center">
    <div class="heading-contact">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-lg-offset-2">
            <div class="wow bounceInDown" data-wow-delay="0.4s">
              <div class="section-heading">
                <h2>Monthly Bill</h2>
                <i class="fa fa-2x fa-angle-down"></i>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="col-md-6">
        <h4 class="text-left">Client Information</h4>
        <?php
          include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/bill_model.php';
          $bill=new bill_model();
          $sql_client=$bill->getOwnerDetails($id);
          $client_data=mysqli_fetch_array($sql_client);
          echo 
          "<div class=col-md-4>
            <p class=text-left>Bill to:</p>
            <p class=text-left>Address:</p>
            <p class=text-left>Contact Number:</p>
          </div>
          <div class=col-md-8 client-data>
            <p class=text-left>".$client_data['fname']."&nbsp".$client_data['lname']."</p>
            <p class=text-left>".$client_data['address']."</p>
            <p class=text-left>".$client_data['contact']."</p>
          </div>";  
        ?>
      </div>
      <div class="col-md-6">
        <h4 class="text-left">Bill Summary</h4>
        <form action="../controller/manage_meter.php?action=add_meter&meternum=<?php echo $meter_id?>" class="form-horizontal" role="form" method="POST">
          <?php
            $bill_id=$bill->GetBillId($meter_id,$id);
            $sql_bill=$bill->GetBillData($bill_id['bill_id']);
            $bill_data=mysqli_fetch_array($sql_bill);
            $sql_meter=$bill->getMeterDetails($meter_id);
            $meter_data=mysqli_fetch_array($sql_meter);
          ?>
          <!--Meter ID input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="meter_id">Bill Number:</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="meter_id" value="<?php echo $bill_data['bill_id']?>" disabled/></div>
          </div>

          <!--Meter Number input-->
          <div class="form-group">
            <label class="col-md-4 control-label" for="meternumber">Meter Number:</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="meter_number" value="<?php echo $meter_data['meter_number']?>" disabled/></div>
          </div>

          <!-- Reading Date input -->
          <div class="form-group">
            <label class="col-md-4 control-label" for="reading_date">Reading Date:</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="reading_date" value="<?php echo $meter_data['reading_date']?>"></div>
          </div>

          <!--Billing Month input -->
          <div class="form-group">
            <label class="col-md-4 control-label" for="billing_month">Billing Month:</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="billing_month" value="<?php echo $meter_data['billing_month']?>"></div>
          </div>

          <!-- Reading input -->
          <div class="form-group">
            <label class="col-md-4 control-label" for="reading">Previous Reading:</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="reading" value="<?php echo $bill_data['previous']?>"></div>
          </div>

          <!-- Reading input -->
          <div class="form-group">
            <label class="col-md-4 control-label" for="reading">Current Reading:</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="reading" value="<?php echo $meter_data['reading']?>"></div>
          </div>

          <!-- Price input -->
          <div class="form-group">
            <label class="col-md-4 control-label" for="price">Price (php):</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="price" value="<?php echo $bill_data['price']?>"></div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label" for="consumption">Total consumption (cubic meter):</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="consumption" value="<?php echo $bill_data['consumption']?>"></div>
          </div>

          <div class="form-group">
            <label class="col-md-4 control-label" for="consumption">Total bill (php):</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="consumption" value="<?php echo $bill_data['totalbill']?>"></div>
          </div>

          <!-- Button -->
          <!-- <div class="form-group">
            <div class="controls col-md-8 col-md-offset-2">
              <button id="singlebutton" name="add" class="btn btn-success pull-right">Save</button>
            </div>
          </div> -->
        </form>
      </div>
    </div>
  </section>
  <!-- /Section: contact -->
</body>

<footer>
  <!-- Core JavaScript Files -->
  <!-- <script src="../js/jquery.min.js"></script> -->
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.min.js"></script>
  <script src="../js/jquery.scrollTo.js"></script>
  <script src="../js/wow.min.js"></script>
  <!-- Custom Theme JavaScript -->
  <script src="../js/custom.js"></script>
  <script src="../contactform/contactform.js"></script>
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-12">
          <div class="wow shake" data-wow-delay="0.4s">
            <div class="page-scroll marginbot-30">
            </div>
          </div>
           <p>&copy;WATERBILLSYSTEM. All rights reserved.</p>
          <div class="credits">
          
            Designed by Dan Alexis B. Francia
          </div>
        </div>
      </div>
    </div>
  </footer>
</html>
