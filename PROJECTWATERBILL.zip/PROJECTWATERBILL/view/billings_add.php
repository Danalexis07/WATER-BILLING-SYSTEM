<?php 
  $meter_no=$_GET['meternum'];
  $reading = "";
  $reading_date = "";
  $billing_month = "";
  $price = "";

  if(isset($_GET['action'])=="edit_meter"){
    include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/meter_model.php';
    $user=new meter_model();
    $result=$user->getMeter($meter_no);
    $data=mysqli_fetch_array($result);

    $title = "EDIT READING";
    $reading = $data['reading'];
    $reading_date = $data['reading_date'];
    $billing_month = $data['billing_month'];
    $price = $data['price'];
  }
  else{
    $title = "ADD NEW READING";    
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>WATERBILL SYSTEM BILLINGS</title>
  <!-- JAVASCRIPT -->
  <script type="text/javascript" src="../js/table/jquery-3.3.1.js"></script>
  <script type="text/javascript" src="../js/table/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="../js/table/jquery-3.3.1.min.js"></script>
  <script type="text/javascript" src="../js/table/datatables.min.js"></script>
  <script type="text/javascript" language="javascript" class="init">
      $(document).ready(function() {
        $('#example').DataTable();
      } );
  </script>
  <!-- Bootstrap Core CSS -->
  <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">

  <!-- Fonts -->
  <link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="../css/animate.css" rel="stylesheet" />
  <!-- Squad theme CSS -->
  <link href="../css/style.css" rel="stylesheet">
  <link href="../color/default.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../css/table/jquery.dataTables.min.css"/>
  <link rel="stylesheet" type="text/css" href="../css/waterbill.css"/>
  <link rel="stylesheet" type="text/css" href="../css/style.css"/>
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
  <!-- Preloader -->
  <!-- <div id="preloader">
    <div id="load"></div>
  </div> -->

  <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
    <div class="container">
      <div class="navbar-header page-scroll">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
        <a class="navbar-brand" href="index.php">
          <h1>WATERBILL SYSTEM</h1>
        </a>
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
        <ul class="nav navbar-nav">
          <li class=""><a href="../view/home.php">Home</a></li>
          <li><a href="../view/billings.php">BILLINGS</a></li>
          <li><a href="../view/clients.php">CLIENTS</a></li>
          <li><a href="../view/logout.php">LOGOUT</a></li>
          <li class="dropdown">

        </ul>
      </div>
      <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
  </nav>

  <!-- Section: intro -->
 

  <!-- Section: contact -->
  <section id="contact" class="home-section text-center">
    <div class="heading-contact">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-lg-offset-2">
            <div class="wow bounceInDown" data-wow-delay="0.4s">
              <div class="section-heading">
                <h2><?php echo $title ?></h2>
                <i class="fa fa-2x fa-angle-down"></i>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <div>
        <form action="../controller/manage_meter.php?action=add_meter&meternum=<?php echo $meter_no?>" class="form-horizontal" role="form" method="POST">
              
          <!--Meter Number input-->
          <div class="form-group">
            <label class="col-md-2 control-label col-md-offset-2" for="meternumber">Meter Number:</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="meter_number" value="<?php echo $meter_no?>" disabled/></div>
          </div>
          
          <!-- Reading input -->
          <div class="form-group">
            <label class="col-md-2 control-label col-md-offset-2" for="reading">Reading:</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="reading" value="<?php echo $reading?>"></div>
          </div>

          <!-- Reading Date input -->
          <div class="form-group">
            <label class="col-md-2 control-label col-md-offset-2" for="reading_date">Reading Date:</label>
            <div class="col-md-6"><input type="date" class="form-control" required="" name="reading_date" value="<?php echo $reading_date?>"></div>
          </div>
          

          <!-- Price input -->
          <div class="form-group">
            <label class="col-md-2 control-label col-md-offset-2" for="price">Price (per cubic meter):</label>
            <div class="col-md-6"><input type="text" class="form-control" required="" name="price" value="<?php echo $price?>"></div>
          </div>

          <!--Billing Month input -->
          <div class="form-group">
            <label class="col-md-2 control-label col-md-offset-2" for="billing_month">Billing Month:</label>
            <div class="col-md-1">
              <select id="billing_month" name="billing_month">
                          <option disabled selected >SELECT MONTH</option>
                          <option>JANUARY</option>
                          <option>FEBRUARY</option>
                          <option>MARCH</option>
                          <option>APRIL</option>
                          <option>MAY</option>
                          <option>JUNE</option>
                          <option>JULY</option>
                          <option>AUGUST</option>
                          <option>SEPTEMBER</option>
                          <option>OCTOBER</option>
                          <option>NOVEMBER</option>
                          <option>DECEMBER</option>
                        </select>
                      </div>
          </div>

          <!-- Button -->
          <div class="form-group">
            <div class="controls col-md-8 col-md-offset-2">
              <button id="singlebutton" name="add" class="btn btn-success pull-right">Save</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </section>
  <!-- /Section: contact -->
</body>

<footer>
  <!-- Core JavaScript Files -->
  <!-- <script src="../js/jquery.min.js"></script> -->
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.min.js"></script>
  <script src="../js/jquery.scrollTo.js"></script>
  <script src="../js/wow.min.js"></script>
  <!-- Custom Theme JavaScript -->
  <script src="../js/custom.js"></script>
  <script src="../contactform/contactform.js"></script>
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-12">
          <div class="wow shake" data-wow-delay="0.4s">
            <div class="page-scroll marginbot-30">
            </div>
          </div>
           <p>&copy;WATERBILLSYSTEM. All rights reserved.</p>
          <div class="credits">
          
            Designed by Dan Alexis B. Francia 
          </div>
        </div>
      </div>
    </div>
  </footer>
</html>
