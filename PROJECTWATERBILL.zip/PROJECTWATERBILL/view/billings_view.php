<?php
  if(isset($_GET['id'])){
    $id = $_GET['id'];
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>WATERBILL SYSTEM BILLINGS</title>
  <!-- JAVASCRIPT -->
  <script type="text/javascript" src="../js/table/jquery-3.3.1.js"></script>
  <script type="text/javascript" src="../js/table/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="../js/table/jquery-3.3.1.min.js"></script>
  <script type="text/javascript" src="../js/table/datatables.min.js"></script>
  <script type="text/javascript" language="javascript" class="init">
      $(document).ready(function() {
        $('#example').DataTable();
      } );
  </script>
  <!-- Bootstrap Core CSS -->
  <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">

  <!-- Fonts -->
  <link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="../css/animate.css" rel="stylesheet" />
  <!-- Squad theme CSS -->
  <link href="../css/style.css" rel="stylesheet">
  <link href="../color/default.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../css/table/jquery.dataTables.min.css"/>
  <link rel="stylesheet" type="text/css" href="../css/waterbill.css"/>
  <link rel="stylesheet" type="text/css" href="../css/style.css"/>
</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">
  <!-- Preloader -->
  <!-- <div id="preloader">
    <div id="load"></div>
  </div> -->

  <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
    <div class="container">
      <div class="navbar-header page-scroll">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                    <i class="fa fa-bars"></i>
                </button>
        <a class="navbar-brand" href="index.php">
          <h1>WATERBILL SYSTEM</h1>
        </a>
      </div>

      <!-- Collect the nav links, forms, and other content for toggling -->
      <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
        <ul class="nav navbar-nav">
          <li class=""><a href="../view/home.php">Home</a></li>
          <li><a href="../view/billings.php">BILLINGS</a></li>
          <li><a href="../view/clients.php">CLIENTS</a></li>
          <li><a href="../view/logout.php">LOGOUT</a></li>
          <li class="dropdown">

        </ul>
      </div>
    </div>
  </nav>
  
  

  <!-- Section: contact -->
  <section id="contact" class="home-section text-center">
    <div class="heading-contact">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-lg-offset-2">
            <div class="wow bounceInDown" data-wow-delay="0.4s">
              <div class="section-heading">
                <h2>METER READINGS</h2>
                <i class="fa fa-2x fa-angle-down"></i>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="container">
      <div>
        <?php
          include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/meter_model.php';
          $meter=new meter_model();
          $owner_data=$meter->getOwnerDetails($id);
          echo "<h4>".$owner_data['fname']."&nbsp".$owner_data['lname']."</h4>";
        ?>
      </div>
      <div>
        <table id="example" class="display table" style="width:100%">
          <thead class="table-client">
              <tr>
                  <th>Meter Id</th>
                  <th>Meter Number</th>
                  <th>Reading</th>
                  <th>Reading Date</th>
                  <th>Billing Month</th>
                  <th>Price</th>
                  <th>Actions</th>
                  <!-- <th>Actions</th> -->
              </tr>
          </thead>
          <tbody> 
            <?php
              $data=$meter->getMeter( $_GET['meternum']);
              $columns=array('meter_id','meter_number','reading','reading_date','billing_month','price');
              while($row=mysqli_fetch_array($data)){
                echo "<tr>";
                foreach($columns as $column){
                  echo "<td>".$row[$column]."</td>";
                }
                $prev=$row['meter_id']-1;
                $isComputed=$meter->checkIsComputed($row['meter_id']);
                if ($isComputed==1) {
                  echo "<td><a class=disabled>compute bill</a>&nbsp | &nbsp <a href=../controller/manage_meter.php?action=view_bill&meterid=".$row['meter_id']."&id=".$id."&previd=".$prev.">view bill</a></td>";
                  echo "</tr>";
                }else{
                  echo "<td><a href=../controller/manage_meter.php?action=compute_bill&meterid=".$row['meter_id']."&id=".$id."&previd=".$prev.">compute bill</a></td>";
                  echo "</tr>";
                }
              }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </section>
  <!-- /Section: contact -->
</body>

<footer>
  <!-- Core JavaScript Files -->
  <!-- <script src="../js/jquery.min.js"></script> -->
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.min.js"></script>
  <script src="../js/jquery.scrollTo.js"></script>
  <script src="../js/wow.min.js"></script>
  <!-- Custom Theme JavaScript -->
  <script src="../js/custom.js"></script>
  <script src="../contactform/contactform.js"></script>

  <!-- The Modal -->
    <div class="modal fade" id="myModal">
      <div class="modal-dialog">
        <div class="modal-content">

          <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Add New Bill</h4>
            <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
          </div>

          <!-- Modal body -->
          <div class="modal-body">
            <form action="../controller/manage_meter.php?action=add_meter" class="form-horizontal" role="form" method="POST">
              
              <!--Meter Number input-->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="meternumber">Meter Number:</label>
                <div class="col-md-6"><input type="text" class="form-control" id="lastname" required="" name="meter_number" value="<?php echo $meternum?>" disabled/></div>
              </div>
              
              <!-- Reading input -->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="reading">Reading:</label>
                <div class="col-md-6"><input type="text" class="form-control" required="" name="reading"></div>
              </div>

              <!-- Reading Date input -->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="reading_date">Reading Date:</label>
                <div class="col-md-6"><input type="text" class="form-control" required="" name="reading_date"></div>
              </div>
              
              <!--Billing Month input -->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="billing_month">Billing Month:</label>
                <div class="col-md-6"><input type="text" class="form-control" required="" name="billing_month"></div>
              </div>

              <!-- Price input -->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="meterno">Price (kwh):</label>
                <div class="col-md-6"><input type="text" class="form-control" required="" name="price"></div>
              </div>

              <!-- Button -->
              <div class="form-group">
                <div class="controls col-md-8 col-md-offset-2">
                  <button id="singlebutton" name="add" class="btn btn-success pull-right">Save</button>
                </div>
              </div>
            </form>
          </div>

          <!-- Modal footer -->
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          </div>

        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-12">
          <div class="wow shake" data-wow-delay="0.4s">
            <div class="page-scroll marginbot-30">
            </div>
          </div>
           <p>&copy;WATERBILLSYSTEM. All rights reserved.</p>
          <div class="credits">
          
            Designed by Dan Alexis B. Francia 
          </div>
        </div>
      </div>
    </div>
  </footer>
</html>
