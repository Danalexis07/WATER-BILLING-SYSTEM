<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>WATERBILL SYSTEM CLIENTS</title>
    <!-- JAVASCRIPT -->
    <script type="text/javascript" src="../js/table/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="../js/table/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="../js/table/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="../js/table/datatables.min.js"></script>
    <script type="text/javascript" language="javascript" class="init">
        $(document).ready(function() {
          $('#example').DataTable();
        } );
    </script>
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">

    <!-- Fonts -->
    <link rel="stylesheet" type="text/css" href="../font-awesome/css/font-awesome.min.css"/>
    <link rel="stylesheet" type="text/css" href="../css/animate.css"/>
    <!-- Squad theme CSS -->
    <link rel="stylesheet" type="text/css" href="../css/style.css"/>
    <link rel="stylesheet" type="text/css" href="../color/default.css"/>
    <link rel="stylesheet" type="text/css" href="../css/table/jquery.dataTables.min.css"/>
    <link rel="stylesheet" type="text/css" href="../css/waterbill.css"/>
  </head>

  <body id="page-top" data-spy="scroll" data-target=".navbar-custom">
    <!-- Preloader -->
    <!-- <div id="preloader">
      <div id="load"></div>
    </div> -->

    <nav class="navbar navbar-custom navbar-fixed-top" role="navigation">
      <div class="container">
        <div class="navbar-header page-scroll">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-main-collapse">
                      <i class="fa fa-bars"></i>
                  </button>
          <a class="navbar-brand" href="../../index.php">
            <h1>WATERBILL SYSTEM</h1>
          </a>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-right navbar-main-collapse">
          <ul class="nav navbar-nav">
            <li class=""><a href="../view/home.php">Home</a></li>
            <li><a href="../view/billings.php">BILLINGS</a></li>
            <li><a href="../view/clients.php">CLIENTS</a></li>
            <li><a href="../view/logout.php">LOGOUT</a></li>
            <li class="dropdown">

          </ul>
        </div>
        <!-- /.navbar-collapse -->
      </div>
      <!-- /.container -->
    </nav>

    <!-- Section: intro -->
    

    <!-- Section: contact -->
    <section id="contact" class="home-section text-center">
      <div class="heading-contact">
        <div class="container">
          <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
              <div class="wow bounceInDown" data-wow-delay="0.4s">
                <div class="section-heading">
                  <h2>CLIENTS</h2>
                  <i class="fa fa-2x fa-angle-down"></i>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div>
          <table id="example" class="display table" style="width:100%">
            <thead class="table-client">
                <tr>
                    <th>Owner Id</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Address</th>
                    <th>Contact No.</th>
                    <th>Meter No.</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody> 
              <?php
                include $_SERVER['DOCUMENT_ROOT'].'/PROJECTWATERBILL/model/client_model.php';
                $client=new client_model();
                $data=$client->getClients();
                $columns=array('owners_id','fname','lname','address','contact','meter_number');
                while($row=mysqli_fetch_array($data)){
                  echo "<tr>";
                  foreach($columns as $column){
                    echo "<td>".$row[$column]."</td>";
                    $id=$row['owners_id'];
                  }
                  echo "<td><a href=../controller/manage_clients.php?action=edit_view&id=".$row['owners_id'].">edit</a>&nbsp|&nbsp<a href=../controller/manage_clients.php?action=delete&id=".$row['owners_id'].">delete</a></td>";
                  echo "</tr>";
                }
              ?>
            </tbody>
          </table>
        </div>
        <!-- Button for the Modal -->
        <div class="text-center">
          <!-- Button to Open the Modal -->
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
            Add Client
          </button>
        </div>
      </div>
    </section>
    <!-- /Section: contact -->
  </body>

  <footer>
    <!-- Core JavaScript Files -->
    <!-- <script src="js/jquery.min.js"></script> -->
    <script type="text/javascript" src="../js/bootstrap.min.js"></script>
    <script type="text/javascript" src="../js/jquery.easing.min.js"></script>
    <script type="text/javascript" src="../js/jquery.scrollTo.js"></script>
    <script type="text/javascript" src="../js/wow.min.js"></script>
    <!-- Custom Theme JavaScript -->
    <script type="text/javascript" src="../js/custom.js"></script>
    <script type="text/javascript" src="../contactform/contactform.js"></script>
    <link rel="stylesheet" type="text/css" href="../font-awesome/css/font-awesome.css"/>

    

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
      <div class="modal-dialog">
        <div class="modal-content">

          <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Add Client</h4>
            <!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
          </div>

          <!-- Modal body -->
          <div class="modal-body">
            <form action="../controller/manage_clients.php?action=add_client" class="form-horizontal" role="form" method="POST">
              <!-- First name input-->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="firstname">First Name:</label>
                <div class="col-md-6"><input type="text" class="form-control" id="firstname" required="" name="fname"/></div>
              </div>
              
              <!--Last name input-->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="lastname">Last Name:</label>
                <div class="col-md-6"><input type="text" class="form-control" id="lastname" required="" name="lname"/></div>
              </div>
              
              <!-- Middle name input -->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="middlename">Middle Name:</label>
                <div class="col-md-6"><input type="text" class="form-control" required="" name="mi"></div>
              </div>

              <!-- Address input -->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="address">Address:</label>
                <div class="col-md-6"><input type="text" class="form-control" required="" name="address"></div>
              </div>
              
              <!-- Contact No. input -->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="contactno">Contact #:</label>
                <div class="col-md-6"><input type="text" class="form-control" required="" name="contact"></div>
              </div>

              <!-- Meter No. input -->
              <div class="form-group">
                <label class="col-md-2 control-label col-md-offset-2" for="meterno">Meter #:</label>
                <div class="col-md-6"><input type="text" class="form-control" required="" name="meter_number"></div>
              </div>

              <!-- Button -->
              <div class="form-group">
                <div class="controls col-md-8 col-md-offset-2">
                  <button id="singlebutton" name="add" class="btn btn-success pull-right">Save</button>
                </div>
              </div>
            </form>
          </div>

          <!-- Modal footer -->
          <div class="modal-footer">
            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
          </div>

        </div>
      </div>
    </div>
  
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-lg-12">
          <div class="wow shake" data-wow-delay="0.4s">
            <div class="page-scroll marginbot-30">
            </div>
          </div>
           <p>&copy;WATERBILLSYSTEM. All rights reserved.</p>
          <div class="credits">
            Designed by Dan Alexis B. Francia
          </div>
        </div>
      </div>
    </div>
  </footer>
</html>
